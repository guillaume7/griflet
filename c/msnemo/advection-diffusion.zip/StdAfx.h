// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__B0082609_691E_461F_943F_161A823B1EED__INCLUDED_)
#define AFX_STDAFX_H__B0082609_691E_461F_943F_161A823B1EED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// TODO: reference additional headers your program requires here
#include <iostream>
#include <math.h>
#include <time.h>
#include <netcdf.h>
#include <string.h>
#include "prog_switches.h"
#include "prog_ind.h"
#include "prog_boo.h"
#include "prog_all.h"
#include "prog_io.h"
#include "prog_cdf.h"
#include "prog_prm.h"
#include "prog_blc.h"
#include "prog_3d.h"
#include "prog_cdf_out.h"
#include "prog_mai.h"

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations 
//immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__B0082609_691E_461F_943F_161A823B1EED__INCLUDED_)
