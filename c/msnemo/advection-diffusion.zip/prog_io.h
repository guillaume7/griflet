#ifndef PROG_IO_H
#define PROG_IO_H

/*Reads an integer from stdin*/
void readint(unsigned int *);

/*Reads a float from stdin*/
void readfloat(double *);
void freadfloat(double *, FILE*);

#endif
