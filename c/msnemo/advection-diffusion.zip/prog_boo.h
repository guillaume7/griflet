/**************definition des variables booleennes************/
#ifndef PROG_BOO_H
#define PROG_BOO_H

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef ON
#define ON 1
#endif

#ifndef OFF
#define OFF 0
#endif

typedef unsigned short int bool_t;
#ifndef CHOICE_T
#define CHOICE_T
//Type de variable de choix dans les case switch.
typedef char choice_t;
#endif

#endif
